import Preview from "./Preview.jsx";

export default function App() {
  return <Preview />;
}
